const { Client, GatewayIntentBits, Collection, Events } = require('discord.js');
const fs = require('node:fs');
const path = require('node:path');
const express = require('express');
const axios = require('axios');
const connectDB = require('./database/mongoose');
require('dotenv').config();

// Inicializar Bot
const client = new Client({ intents: [GatewayIntentBits.Guilds] });
client.commands = new Collection();

// Carregar Comandos
const foldersPath = path.join(__dirname, 'commands');
const commandFolders = fs.readdirSync(foldersPath);

for (const folder of commandFolders) {
    const commandsPath = path.join(foldersPath, folder);
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
    for (const file of commandFiles) {
        const filePath = path.join(commandsPath, file);
        const command = require(filePath);
        if ('data' in command && 'execute' in command) {
            client.commands.set(command.data.name, command);
        }
    }
}

// Evento: Bot Pronto
client.once(Events.ClientReady, c => {
    console.log(`✅ Bot online como ${c.user.tag}`);
    connectDB();
});

// Evento: Interação
client.on(Events.InteractionCreate, async interaction => {
    if (!interaction.isChatInputCommand()) return;

    const command = interaction.client.commands.get(interaction.commandName);
    if (!command) return;

    try {
        await command.execute(interaction);
    } catch (error) {
        console.error(error);
        await interaction.reply({ content: 'Houve um erro ao executar este comando!', ephemeral: true });
    }
});

// Servidor Express para Keep-Alive
const app = express();
const PORT = process.env.PORT || 3000;

app.get('/', (req, res) => {
    res.send('FinanceBot está online! 🚀');
});

app.listen(PORT, () => {
    console.log(`🌐 Servidor Keep-Alive rodando na porta ${PORT}`);
});

// Sistema de Auto-Ping (Keep-Alive)
if (process.env.APP_URL) {
    setInterval(() => {
        axios.get(process.env.APP_URL)
            .then(() => console.log('Ping enviado para manter o bot acordado.'))
            .catch(err => console.error('Erro no auto-ping:', err.message));
    }, 300000); // A cada 5 minutos
}

client.login(process.env.DISCORD_TOKEN);
