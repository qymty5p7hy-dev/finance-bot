# 🚀 Guia Rápido: FinanceBot no Render (24/7)

Siga estes passos para deixar seu bot online para sempre:

### 1. Criar o Repositório
1. Vá ao seu [GitHub](https://github.com/) e crie um novo repositório chamado `finance-bot`.
2. Suba todos os arquivos da pasta que te enviei (exceto a pasta `node_modules` e o arquivo `.env`).

### 2. Configurar no Render
1. Acesse o [Dashboard do Render](https://dashboard.render.com/).
2. Clique em **New +** -> **Web Service**.
3. Conecte seu GitHub e selecione o repositório `finance-bot`.
4. **Configurações:**
   - **Runtime:** `Node`
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
5. Clique em **Advanced** -> **Add Environment Variable** e adicione estas 4:

| Key | Value |
| :--- | :--- |
| `DISCORD_TOKEN` | `MTQ3Mjc0MjM2NjU1MTk5ODY1OQ.GHlOgz._qkVBh5RKsX1k6GUk_Vp7Noxh0qWy5wiU_utts` |
| `CLIENT_ID` | `1472742366551998659` |
| `MONGODB_URI` | `mongodb+srv://Motoca16:josineidemota@cluster0.3hnigcn.mongodb.net/?appName=Cluster0` |
| `PORT` | `3000` |

### 3. Manter Online (Keep-Alive)
1. Após o deploy terminar, o Render vai te dar uma URL (ex: `https://finance-bot.onrender.com`).
2. Vá em **Environment** no Render e adicione mais uma variável:
   - **Key:** `APP_URL`
   - **Value:** (A URL que o Render te deu)

Pronto! Seu bot agora vai se "auto-pingar" a cada 5 minutos para nunca dormir. 🚀
