# Instruções de Deploy no Render para o FinanceBot

Este guia detalha os passos para realizar o deploy do seu FinanceBot no Render, garantindo que ele permaneça online 24/7 utilizando os recursos do plano gratuito.

## Pré-requisitos

*   Conta no GitHub (ou similar) para hospedar o código do bot.
*   Conta no Render (https://render.com/).
*   Conta no MongoDB Atlas (https://cloud.mongodb.com/) com um cluster gratuito configurado (veja o guia de configuração do MongoDB Atlas).
*   Um aplicativo Discord Bot criado e configurado no [Portal do Desenvolvedor do Discord](https://discord.com/developers/applications).

## 1. Preparar o Código para o Deploy

Certifique-se de que seu projeto FinanceBot está na estrutura correta e com todas as dependências instaladas (`npm install`). O arquivo `package.json` deve conter o script `start` apontando para `node src/index.js`.

## 2. Configurar Variáveis de Ambiente

No seu projeto local, você tem um arquivo `.env.example`. Para o deploy, você precisará definir essas variáveis diretamente no Render. As variáveis essenciais são:

*   `DISCORD_TOKEN`: O token do seu bot Discord.
*   `CLIENT_ID`: O ID do cliente (Application ID) do seu bot Discord.
*   `MONGODB_URI`: A string de conexão do seu cluster MongoDB Atlas.
*   `PORT`: A porta que o servidor Express irá escutar (ex: `3000`). O Render injeta a porta automaticamente, mas é bom ter um fallback.
*   `APP_URL`: A URL pública do seu serviço Render após o deploy. Você precisará atualizar esta variável após o primeiro deploy.

## 3. Criar um novo serviço no Render

1.  Acesse o [dashboard do Render](https://dashboard.render.com/).
2.  Clique em `New` e selecione `Web Service`.
3.  Conecte sua conta GitHub (ou GitLab) e selecione o repositório do seu FinanceBot.
4.  Configure as seguintes opções:
    *   **Name**: `financebot` (ou o nome que preferir)
    *   **Region**: Escolha a região mais próxima de você ou dos seus usuários.
    *   **Branch**: `main` (ou a branch principal do seu projeto)
    *   **Root Directory**: Deixe em branco se o seu `package.json` estiver na raiz do repositório, ou especifique a pasta se for um subdiretório (ex: `finance-bot`).
    *   **Runtime**: `Node`
    *   **Build Command**: `npm install`
    *   **Start Command**: `npm start`
    *   **Plan Type**: `Free`

## 4. Adicionar Variáveis de Ambiente no Render

1.  Na seção `Environment` do seu novo serviço, clique em `Add Environment Variable`.
2.  Adicione cada uma das variáveis listadas no passo 2 (`DISCORD_TOKEN`, `CLIENT_ID`, `MONGODB_URI`, `PORT`, `APP_URL`).
    *   Para `APP_URL`, você pode deixar em branco no primeiro deploy. Após o deploy bem-sucedido, o Render fornecerá uma URL pública para o seu serviço. Edite esta variável com a URL fornecida.

## 5. Deploy Inicial

1.  Após configurar tudo, clique em `Create Web Service`.
2.  O Render irá clonar seu repositório, instalar as dependências e iniciar o bot.
3.  Monitore os logs para garantir que o deploy foi bem-sucedido e que o bot está online.

## 6. Configurar Keep-Alive (Ping Automático)

Para garantir que o bot permaneça online 24/7 no plano gratuito do Render, que pode hibernar serviços inativos, você precisa de um serviço de monitoramento externo.

1.  **Obtenha a URL do seu serviço Render**: Após o deploy, vá para a página do seu serviço no Render. A URL pública será exibida (ex: `https://financebot.onrender.com`).
2.  **Atualize `APP_URL` no Render**: Edite a variável de ambiente `APP_URL` no Render com a URL obtida no passo anterior. Isso permitirá que o próprio bot se pingue.
3.  **Configure o UptimeRobot (ou similar)**:
    *   Crie uma conta gratuita no [UptimeRobot](https://uptimerobot.com/).
    *   Clique em `Add New Monitor`.
    *   **Monitor Type**: `HTTP(s)`
    *   **Friendly Name**: `FinanceBot Keep-Alive`
    *   **URL (or IP)**: Cole a URL pública do seu serviço Render.
    *   **Monitoring Interval**: `5 Minutes` (ou o menor intervalo permitido pelo plano gratuito).
    *   Clique em `Create Monitor`.

O UptimeRobot irá pingar seu bot a cada 5 minutos, mantendo-o ativo e prevenindo a hibernação. O próprio bot também possui um mecanismo de auto-ping para maior robustez.

## 7. Registrar Comandos Slash no Discord

Após o deploy, você precisará registrar os comandos slash do seu bot no Discord. Isso é feito executando o script `deploy-commands.js`.

1.  **Localmente**: Certifique-se de ter as variáveis `DISCORD_TOKEN` e `CLIENT_ID` configuradas no seu `.env` local.
2.  Abra o terminal na raiz do seu projeto e execute:
    ```bash
    npm run deploy
    ```
3.  Você verá uma mensagem de sucesso no console se os comandos forem registrados corretamente.

Se preferir, você pode configurar um pipeline de CI/CD no Render para executar o `npm run deploy` automaticamente após cada deploy bem-sucedido, mas para um projeto simples, a execução manual é suficiente.

Com esses passos, seu FinanceBot estará online, conectado ao MongoDB Atlas e pronto para uso no Discord 24/7!
