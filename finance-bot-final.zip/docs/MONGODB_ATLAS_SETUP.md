# Configuração do MongoDB Atlas para o FinanceBot

Este guia detalha os passos para configurar um cluster gratuito no MongoDB Atlas e obter a string de conexão (`MONGODB_URI`) necessária para o seu FinanceBot.

## 1. Criar uma Conta no MongoDB Atlas

1.  Acesse o site do [MongoDB Atlas](https://cloud.mongodb.com/).
2.  Clique em `Try Free` ou `Sign Up` e crie sua conta. Você pode usar sua conta Google ou GitHub para facilitar.

## 2. Criar um Novo Projeto

1.  Após fazer login, você será direcionado ao painel do Atlas.
2.  Clique em `New Project`.
3.  Dê um nome ao seu projeto (ex: `FinanceBot-Project`) e clique em `Next`.
4.  Adicione membros se desejar (opcional) e clique em `Create Project`.

## 3. Criar um Cluster Gratuito (M0 Sandbox)

1.  No painel do projeto, clique em `Build a Database`.
2.  Escolha a opção `Shared` (que é o plano gratuito M0 Sandbox).
3.  Selecione um provedor de nuvem e uma região. Recomenda-se escolher a região mais próxima de onde seu bot será hospedado (ex: AWS N. Virginia para Render).
4.  Deixe as outras configurações como padrão.
5.  Clique em `Create Cluster`.

Levará alguns minutos para o cluster ser provisionado.

## 4. Configurar Acesso à Rede

Para que seu bot (e o Render) possa se conectar ao seu banco de dados, você precisa configurar as regras de acesso à rede.

1.  No menu lateral esquerdo, vá para `Network Access` (em `Security`).
2.  Clique em `Add IP Address`.
3.  Selecione `Allow Access from Anywhere` para simplificar (para fins de desenvolvimento e deploy gratuito). **Atenção**: Em um ambiente de produção real, você deve restringir o acesso apenas aos IPs conhecidos do seu servidor.
4.  Clique em `Confirm`.

## 5. Criar um Usuário de Banco de Dados

Você precisa de um usuário com permissões para acessar o banco de dados.

1.  No menu lateral esquerdo, vá para `Database Access` (em `Security`).
2.  Clique em `Add New Database User`.
3.  Escolha `Password` como método de autenticação.
4.  Crie um **Username** (ex: `financebot_user`) e uma **Password forte**. **Anote esta senha**, pois você precisará dela para a string de conexão.
5.  Em `Database User Privileges`, selecione `Read and write to any database`.
6.  Clique em `Add User`.

## 6. Obter a String de Conexão (MONGODB_URI)

1.  No painel do seu cluster, clique em `Connect`.
2.  Selecione `Connect your application`.
3.  Escolha `Node.js` como driver e a versão mais recente.
4.  Copie a string de conexão fornecida. Ela será algo parecido com:
    ```
    mongodb+srv://<username>:<password>@cluster0.abcde.mongodb.net/?retryWrites=true&w=majority
    ```
5.  **Substitua `<username>`** pelo nome de usuário que você criou (ex: `financebot_user`).
6.  **Substitua `<password>`** pela senha que você criou para o usuário do banco de dados.
7.  A string de conexão final será o seu `MONGODB_URI`.

Exemplo:
```
mongodb+srv://financebot_user:SUA_SENHA_AQUI@cluster0.abcde.mongodb.net/?retryWrites=true&w=majority
```

Utilize esta `MONGODB_URI` no seu arquivo `.env` local e nas variáveis de ambiente do Render.
